UNZIP FIRST
run .exe

Left Click to drag logic gates onto the grid and click on red nodes to connect wires.
Right click to remove wires.
Test your solutions and try and solve the puzzles!

Click on those pesky bugs to squash them.
